支持Alkaline类型的电池图标文件,如有需要你可以下载Alkaline的电池图标文件解压到这里即可,同时你也可以按照自带的文件格式开发自己喜欢的电池图标.
Alkaline电池图标下载:http://apt.niceios.com/debs/Alkaline.zip

 
When necessary, you can download the battery ICONS file and just extract here. In the meantime, you can also develop your favorite battery ICONS according to the default file naming.

Alkaline battery icon to download: http://apt.niceios.com/debs/Alkaline.zip

